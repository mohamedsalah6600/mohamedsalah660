<?php


function lang($phrase){

	static $lang = array(



);
		return $lang[$phrase];

}



?>