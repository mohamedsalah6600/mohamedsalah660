
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php title()?></title>
			<link rel="stylesheet" href="layouts/css/bootstrap.min.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="layouts/css/fontawesome.min.css">

				<link rel="stylesheet" href="layouts/css/file.css">

</head>
<body>



