<!-- I dont Care About it in Website 
	But i Remember it's very very easy -->

<?php


function lang($phrase){

	static $lang = array(



);
		return $lang[$phrase];

}



?>