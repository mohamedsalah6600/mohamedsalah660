<?php


function lang($phrase){

	static $lang = array(

		'message' =>'اهﻻ'



		);
		return $lang[$phrase];

}



?>