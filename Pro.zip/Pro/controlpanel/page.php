<!-- It's Not Important to The project  ->


<?php

$do = "";

	if (isset($_GET['do'])) {
		$do = $_GET['do'];
	}else{
		$do = "manage";
	}
/*
Can Write it like that

$do = isset($_GET['do']) ? $_GET['do'] : 'manage';

*/


	if ($do == manage) {

		echo "Welcome";

		echo "<a href='?do=Insert'>Add new Category </a>";

	}elseif ($do == Add) {
		echo "Welcome You Are In Category";
			}elseif ($do == Insert) {
		echo "Welcome You Are In Insert Page";

	}else{
		echo "Error";
	}


?>